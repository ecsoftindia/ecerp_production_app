import { Injectable } from '@angular/core';
import {
  NativeGeocoder,
  NativeGeocoderOptions,
  NativeGeocoderResult,
} from '@awesome-cordova-plugins/native-geocoder/ngx';
import { Geolocation } from '@capacitor/geolocation';
import { NavController, Platform } from '@ionic/angular';
// import { AndroidSettings, NativeSettings } from 'capacitor-native-settings';
@Injectable({
  providedIn: 'root',
})
export class LocationService {
  coordinates = {
    latitude: 0,
    longitude: 0,
    accuracy: 0,
    altitudeAccuracy: null,
    altitude: null,
    speed: null,
    heading: null,
  };
  locationAddress = {
    latitude: '',
    longitude: '',
    countryCode: '',
    postalCode: '',
    administrativeArea: '',
    subAdministrativeArea: '',
    locality: '',
    subLocality: '',
    thoroughfare: '',
    subThoroughfare: '',
    areasOfInterest: [],
  };
  locationPermissionStatus = ['denied', 'prompt', 'granted'];
  hasLocationPermission = false;

  // reverse coding;
  reverseOptions: NativeGeocoderOptions = {
    useLocale: true,
    maxResults: 5,
  };

  constructor(
    public platform: Platform,
    public router: NavController,
    private nativeGeocoder: NativeGeocoder
  ) {}

  // async init() {
  //   return new Promise(async (resolve) => {
  //     let permission = await Geolocation.checkPermissions();
  //     //console.log(permission);
  //     if (permission.location === 'granted') {
  //       const coordinates = await Geolocation.getCurrentPosition(
  //         {
  //           enableHighAccuracy: false,
  //           timeout: 10000,
  //         }
  //       );
  //       //console.log(coordinates);
  //       this.coordinates = coordinates.coords;
  //       this.hasLocationPermission = true;
  //       resolve(true);
  //     } else {
  //       if (this.platform.is('android')) {
  //         let request = await Geolocation.requestPermissions();
  //         if (request.location !== 'granted') {
  //           this.hasLocationPermission = false;
  //           resolve(false);
  //         } else {
  //           const coordinates = await Geolocation.getCurrentPosition(
  //             {
  //               enableHighAccuracy: false,
  //               timeout: 10000,
  //             }
  //           );
  //           this.coordinates = coordinates.coords;
  //           this.hasLocationPermission = true;
  //           resolve(true);
  //         }
  //       }
  //     }
  //   });
  // }

  async init() {
    return new Promise(async (resolve) => {
      let option: any = {
        enableHighAccuracy: true,
        timeout: 10000,
      };
      const coordinates = await Geolocation.getCurrentPosition(option);
      // //console.log(coordinates);
      this.coordinates = coordinates.coords;
      // //console.log(this.coordinates);
      this.hasLocationPermission = true;
      resolve(true);
    });
  }

  async openSettings() {
    return new Promise(async (resolve) => {
      if (this.platform.is('android')) {
        let request = await Geolocation.requestPermissions();
        if (request.location !== 'granted') {
          this.hasLocationPermission = false;
          // NativeSettings.openAndroid({
          //   option: AndroidSettings.ApplicationDetails,
          // });
          return resolve(false);
        } else {
          const coordinates = await Geolocation.getCurrentPosition({
            enableHighAccuracy: false,
            timeout: 10000,
          });
          this.coordinates = coordinates.coords;
          this.hasLocationPermission = true;
          return resolve(true);
        }
      }
    });
  }

  getAddress() {
    return new Promise((resolve) => {
      if (this.platform.is('android')) {
        this.nativeGeocoder
          .reverseGeocode(
            this.coordinates.latitude,
            this.coordinates.longitude,
            this.reverseOptions
          )
          .then((result: NativeGeocoderResult[]) => {
            this.locationAddress = result[0];
            //console.log(JSON.stringify(result[0]));
            resolve(this.locationAddress);
          })
          .catch((error: any) => {
            this.ClearAddress();
            //console.log(error);
            resolve(false);
          });
      } else {
        this.ClearAddress();
        resolve(false);
      }
    });
  }

  getAddressByPoint(latitude, longitude) {
    return new Promise((resolve, reject) => {
      if (this.platform.is('android')) {
        this.nativeGeocoder
          .reverseGeocode(latitude, longitude, this.reverseOptions)
          .then((result: NativeGeocoderResult[]) => {
            let locationAddress = result[0];
            resolve(locationAddress);
          })
          .catch((error: any) => {
            reject(false);
          });
      } else {
        reject(false);
      }
    });
  }

  ClearAddress() {
    this.locationAddress = {
      latitude: '',
      longitude: '',
      countryCode: '',
      postalCode: '',
      administrativeArea: '',
      subAdministrativeArea: '',
      locality: '',
      subLocality: '',
      thoroughfare: '',
      subThoroughfare: '',
      areasOfInterest: [],
    };
  }
}
