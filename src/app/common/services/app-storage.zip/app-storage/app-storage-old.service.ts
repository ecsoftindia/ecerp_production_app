import { Injectable } from '@angular/core';
import {
  CapacitorSQLite,
  capSQLiteChanges,
  capSQLiteResult,
  SQLiteConnection,
  SQLiteDBConnection,
} from '@capacitor-community/sqlite';
import { Capacitor } from '@capacitor/core';
import { AlertController } from '@ionic/angular';
import { format } from 'date-fns';
import { dbschema } from './app-storage-db-schema';

export const DB_JSON = {
  database: 'fnpf_ndma_v4',
  version: 4,
  encrypted: true,
  mode: 'full',
  tables: [
    {
      name: 'app_data',
      schema: [
        { column: 'id', value: 'INTEGER PRIMARY KEY NOT NULL' },
        { column: 'key_name', value: 'TEXT NOT NULL' },
        { column: 'value_data', value: 'TEXT NOT NULL' },
        {
          column: 'date_added',
          value: "INTEGER DEFAULT (strftime('%s', 'now'))",
        },
        { column: 'last_modified', value: 'INTEGER' },
      ],
      values: [],
    },
    {
      name: 'offline_login',
      schema: [
        { column: 'id', value: 'INTEGER PRIMARY KEY NOT NULL' },
        {
          column: 'login_date',
          value: "INTEGER DEFAULT (strftime('%s', 'now'))",
        },
        { column: 'login_data', value: 'TEXT NOT NULL' },
        { column: 'last_modified', value: 'INTEGER' },
      ],
      values: [],
    },
    {
      name: 'member_info',
      schema: [
        { column: 'id', value: 'INTEGER PRIMARY KEY NOT NULL' },
        {
          column: 'fnpf_no',
          value: 'TEXT NOT NULL',
        },
        { column: 'member_data', value: 'TEXT NOT NULL' },
        { column: 'last_modified', value: 'INTEGER' },
        {
          column: 'first_name',
          value: 'TEXT NULL',
        },
        {
          column: 'father_name',
          value: 'TEXT NULL',
        },
        {
          column: 'tin',
          value: 'TEXT NULL',
        },
        {
          column: 'dob',
          value: 'TEXT NULL',
        },
        {
          column: 'legacy_member_id',
          value: 'TEXT NULL',
        },
      ],
      values: [],
    },
    {
      name: 'nd_withdrawal_application',
      schema: [
        { column: 'id', value: 'INTEGER PRIMARY KEY NOT NULL' },
        {
          column: 'fnpf_no',
          value: 'TEXT NOT NULL',
        },
        { column: 'application_detail', value: 'TEXT NULL' },
        { column: 'sync_flag', value: 'TEXT NOT NULL' },
        { column: 'application_status', value: 'TEXT NOT NULL' },
        { column: 'latitude', value: 'REAL NULL' },
        { column: 'longitude', value: 'REAL NULL' },
        { column: 'last_modified', value: 'INTEGER' },
      ],
      values: [],
    },
    {
      name: 'submitted_nd_withdrawal_application',
      schema: [
        { column: 'id', value: 'INTEGER PRIMARY KEY NOT NULL' },
        {
          column: 'fnpf_no',
          value: 'TEXT NOT NULL',
        },
        { column: 'geo_location', value: 'TEXT NULL' },
        { column: 'member_first_name', value: 'TEXT NULL' },
        { column: 'member_full_name', value: 'TEXT NULL' },
        { column: 'application_status', value: 'TEXT NOT NULL' },
        { column: 'latitude', value: 'REAL NULL' },
        { column: 'longitude', value: 'REAL NULL' },
        { column: 'last_modified', value: 'INTEGER' },
      ],
      values: [],
    },
  ],
};

@Injectable({
  providedIn: 'root',
})
export class AppStorageOldService {
  platform: string = '';
  sqlitePlugin: any;
  sqlite: SQLiteConnection;
  isService: boolean = false;
  native: boolean = false;
  private initPlugin: boolean = false;
  public isWeb: boolean = false;
  db: SQLiteDBConnection;
  constructor(public alertCtrl: AlertController) { }

  initializeSQlite(): Promise<boolean> {
    return new Promise((resolve) => {
      this.platform = Capacitor.getPlatform();
      // //console.log(this.platform);
      if (this.platform === 'ios' || this.platform === 'android') {
        this.native = true;
      }
      this.sqlitePlugin = CapacitorSQLite;
      this.sqlite = new SQLiteConnection(this.sqlitePlugin);
      this.isService = true;
      resolve(true);
    });
  }

  init() {
    this.initializeSQlite().then(async (res) => {
      this.initPlugin = res;
      const p: string = this.platform;

      if (p === 'web') {
        this.isWeb = true;
        await customElements.whenDefined('jeep-sqlite');
        const jeepSqliteEl: any = document.querySelector('jeep-sqlite');
        // //console.log(jeepSqliteEl);
        if (jeepSqliteEl != null) {
          await this.initWebStore();
        } else {
          this.showAlert('jeepSqliteEl is null');
          //console.log('$$ jeepSqliteEl is null');
        }
      }
      try {
        let dbAvailable = await this.isDatabase(DB_JSON.database);
        //console.log(dbAvailable);
        // if (!dbAvailable.result) {
        //   let result = await this.isJsonValid(JSON.stringify(DB_JSON));
        //   // //console.log(result);
        //   if (!result.result) {
        //     this.showAlert('DB_JSON IsJsonValid failed');
        //   } else {
        //     this.importdb();
        //   }
        // } else {
        //   // //console.log('dbavailable');
        //   this.createDBconnection();
        //   // if (DB_JSON.resetdb) {
        //   //   this.importdb();
        //   //   // //console.log(importjson)
        //   // }
        // }
      } catch (error) {
        this.showAlert(`Error: ${error}`);
        //console.log(`Error: ${error}`);
        this.initPlugin = false;
      }
    });
  }

  async importdb() {
    let db = await this.createConnection(
      DB_JSON.database,
      false,
      "no-encryption",
      DB_JSON.version
    );
    await this.sqlite.closeConnection(DB_JSON.database);
    let dbencrypt = await this.createConnection(
      DB_JSON.database,
      true,
      "encryption",
      DB_JSON.version
    );
    await this.sqlite.closeConnection(DB_JSON.database);
    let dbsecret = await this.createConnection(
      DB_JSON.database,
      true,
      "secret",
      DB_JSON.version
    );
    await dbsecret.open();
    let ret: any = await dbsecret.execute(dbschema);
    await dbsecret.close();
    await this.sqlite.closeConnection(DB_JSON.database);
    if (ret.changes.changes < 0) {
      this.showAlert("Execute createSchema failed");
      //console.log(new Error("Execute createSchema failed"));
    } else {
      // this.createDBconnection();
    }


    // let importjson = await this.importFromJson(JSON.stringify(DB_JSON));
    // if (importjson.changes.changes === -1) {
    //   this.showAlert("ImportFromJson 'full' dataToImport failed");
    // } else {

    //   this.createDBconnection();
    //   // let connection = await this.sqlite.createConnection(DB_JSON.database, DB_JSON.encrypted, DB_JSON.mode, DB_JSON.version);
    // }
  }

  async showAlert(msg) {
    const alert = await this.alertCtrl.create({
      header: 'Error',
      message: msg,
      buttons: ['OK'],
    });
    await alert.present();
  }

  async initWebStore(): Promise<void> {
    if (this.platform !== 'web') {
      return Promise.reject(
        new Error(`not implemented for this platform: ${this.platform}`)
      );
    }
    if (this.sqlite != null) {
      try {
        await this.sqlite.initWebStore();
        return Promise.resolve();
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }

  async createConnection(
    database: string,
    encrypted: boolean,
    mode: string,
    version: number
  ): Promise<SQLiteDBConnection> {
    if (this.sqlite != null) {
      try {
        const db: SQLiteDBConnection = await this.sqlite.createConnection(
          database,
          encrypted,
          mode,
          version
        );
        if (db != null) {
          return Promise.resolve(db);
        } else {
          return Promise.reject(new Error(`no db returned is null`));
        }
      } catch (err) {
        //console.log(err);
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open for ${database}`));
    }
  }

  async isConnection(database: string): Promise<capSQLiteResult> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(await this.sqlite.isConnection(database));
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }

  async retrieveConnection(database: string): Promise<SQLiteDBConnection> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(await this.sqlite.retrieveConnection(database));
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open for ${database}`));
    }
  }

  async importFromJson(jsonstring: string): Promise<capSQLiteChanges> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(await this.sqlite.importFromJson(jsonstring));
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }

  async isJsonValid(jsonstring: string): Promise<capSQLiteResult> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(await this.sqlite.isJsonValid(jsonstring));
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }

  async isDatabase(database: string): Promise<capSQLiteResult> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(await this.sqlite.isDatabase(database));
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }

  uuidv4() {
    return Math.random().toString().slice(2, 11);
  }

  async createDBconnection() {
    if ((await this.isConnection(DB_JSON.database)).result) {
      this.db = await this.retrieveConnection(DB_JSON.database);
    } else {
      // //console.log(DB_JSON);
      this.db = await this.createConnection(
        DB_JSON.database,
        DB_JSON.encrypted,
        "secret",
        DB_JSON.version
      );
    }
  }



  setData(key, value): Promise<boolean> {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        "SELECT * FROM app_data WHERE key_name = '" + key + "';"
      );
      let jvalue = JSON.stringify(value);
      jvalue = jvalue.replace(/\'/g, "''");
      const date_added = format(new Date(), 'yyyy-MM-dd HH:mm');
      if (qryResponse.values.length === 0) {
        const id = this.uuidv4();
        let insertQry =
          "INSERT INTO app_data (id, key_name, value_data, date_added) VALUES ('" +
          id +
          "', '" +
          key +
          "', '" +
          jvalue +
          "', '" +
          date_added +
          "');";
        let insertResponse = await this.db.run(insertQry);
        if (insertResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(insertResponse);
        }
      } else {
        // //console.log('Update Qry');
        let updateQry =
          "UPDATE app_data SET value_data = '" +
          jvalue +
          "' WHERE key_name = '" +
          key +
          "'";
        let updateResponse = await this.db.execute(updateQry);
        if (updateResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(updateResponse);
        }
      }
    });
  }


  hasDB() {
    return new Promise((resolve) => {
      resolve(true);
      // const interval = setInterval(() => {
      //   if (this.db) {
      //     clearInterval(interval);
      //     resolve(true);
      //   }
      // }, 400);
    });
  }

  getData(key) {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        "SELECT * FROM app_data WHERE key_name = '" + key + "';"
      );
      await this.db.close();
      if (qryResponse.values.length === 0) {
        return resolve(null);
      } else {
        let data = qryResponse.values[0];
        // //console.log(data);
        return resolve(JSON.parse(data.value_data));
      }
    });
  }

  insertData(tableName, values): Promise<any> {
    return new Promise(async (resolve) => {
      let keys = 'id, ';
      const id = this.uuidv4();
      let newValues = "'" + id + "', ";
      for (let [key, value] of Object.entries(values)) {
        keys = keys + key + ', ';
        newValues = newValues + "'" + value + "', ";
      }
      let insertQuery =
        'INSERT INTO ' +
        tableName +
        ' (' +
        keys +
        ') VALUES (' +
        newValues +
        ')';
      await this.hasDB();
      await this.db.open();
      let insertResponse = await this.db.run(insertQuery);
      await this.db.close();
      if (insertResponse.changes) {
        resolve(true);
      } else {
        this.showAlert(insertResponse);
      }
    });
  }

  setMemberData(
    key,
    value,
    first_name,
    father_name,
    tin,
    dob,
    legacy_member_id
  ): Promise<boolean> {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        "SELECT * FROM member_info WHERE fnpf_no = '" + key + "';"
      );
      let jvalue = JSON.stringify(value);
      jvalue = jvalue.replace(/\'/g, "''");
      if (qryResponse.values.length === 0) {
        const id = this.uuidv4();
        let insertQry =
          "INSERT INTO member_info (id, fnpf_no, member_data,first_name,father_name,tin,dob,legacy_member_id) VALUES ('" +
          id +
          "', '" +
          key +
          "', '" +
          jvalue +
          "', '" +
          first_name +
          "', '" +
          father_name +
          "', '" +
          tin +
          "', '" +
          dob +
          "', '" +
          legacy_member_id +
          "');";
        let insertResponse = await this.db.run(insertQry);
        if (insertResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(insertResponse);
        }
      } else {
        // //console.log('Update Qry');
        let updateQry =
          "UPDATE member_info SET member_data = '" +
          jvalue +
          "',first_name = '" +
          first_name +
          "',father_name = '" +
          father_name +
          "',tin = '" +
          tin +
          "',dob = '" +
          dob +
          "',legacy_member_id = '" +
          legacy_member_id +
          "' WHERE fnpf_no = '" +
          key +
          "'";
        let updateResponse = await this.db.execute(updateQry);
        if (updateResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(updateResponse);
        }
      }
    });
  }

  getMemberData(query) {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(query);
      await this.db.close();
      if (qryResponse.values.length === 0) {
        return resolve(null);
      } else {
        let data = qryResponse.values[0].member_data;
        return resolve(JSON.parse(data));
      }
    });
  }

  getSyncedMemberCount() {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        'SELECT  COUNT(*) AS COUNT FROM member_info;'
      );
      if (qryResponse.values.length === 0) {
        return resolve(null);
      } else {
        let data = qryResponse.values[0];
        return resolve(data.COUNT);
      }
    });
  }

  setNDapplicationData(
    fnpf_no,
    application_details,
    sync_status,
    application_status
  ): Promise<boolean> {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        "SELECT * FROM nd_withdrawal_application WHERE fnpf_no = '" +
        fnpf_no +
        "';"
      );
      let jvalue = JSON.stringify(application_details);
      jvalue = jvalue.replace(/\'/g, "''");
      if (qryResponse.values.length === 0) {
        const id = this.uuidv4();
        let insertQry =
          "INSERT INTO nd_withdrawal_application (id, fnpf_no, application_detail, sync_flag, application_status) VALUES ('" +
          id +
          "', '" +
          fnpf_no +
          "', '" +
          jvalue +
          "', '" +
          sync_status +
          "', '" +
          application_status +
          "');";
        //console.log(insertQry);
        let insertResponse = await this.db.run(insertQry);
        if (insertResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(insertResponse);
        }
      } else {
        let updateQry =
          "UPDATE nd_withdrawal_application SET application_detail = '" +
          jvalue +
          "',sync_flag = '" +
          sync_status +
          "',application_status = '" +
          application_status +
          "' WHERE fnpf_no = '" +
          fnpf_no +
          "'";
        let updateResponse = await this.db.execute(updateQry);
        if (updateResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(updateResponse);
        }
      }
      await this.db.close();
    });
  }

  UpdateNDapplicationAndGeoLocattion(
    fnpf_no,
    application_details,
    sync_status,
    application_status,
    geolocation
  ): Promise<boolean> {
    let latitude = 0;
    let longitude = 0;

    if (geolocation && geolocation !== '' && geolocation !== '{}') {
      let location = JSON.parse(geolocation);
      if (location && location.latitude && location.longitude) {
        longitude = location.longitude;
        latitude = location.latitude;
      }
    }

    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let jvalue = JSON.stringify(application_details);
      jvalue = jvalue.replace(/\'/g, "''");
      let updateQry =
        "UPDATE nd_withdrawal_application SET application_detail = '" +
        jvalue +
        "',sync_flag = '" +
        sync_status +
        "',application_status = '" +
        application_status +
        "',latitude = " +
        latitude +
        ',longitude = ' +
        longitude +
        " WHERE fnpf_no = '" +
        fnpf_no +
        "'";
      let updateResponse = await this.db.execute(updateQry);
      if (updateResponse.changes) {
        resolve(true);
      } else {
        this.showAlert(updateResponse);
      }

      await this.db.close();
    });
  }

  getNDapplicationData(key) {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        "SELECT * FROM nd_withdrawal_application WHERE fnpf_no = '" + key + "';"
      );
      await this.db.close();
      if (qryResponse.values.length === 0) {
        return resolve(null);
      } else {
        //console.log(qryResponse);
        let data = qryResponse.values[0];
        return resolve(data);
      }
    });
  }

  getunsyncedSubmittedNDapplicationCount() {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        "SELECT COUNT(*) AS COUNT FROM nd_withdrawal_application WHERE sync_flag = 'N' and application_status='SBMTD';"
      );
      await this.db.close();
      if (qryResponse.values.length === 0) {
        return resolve(0);
      } else {
        let data = qryResponse.values[0];
        // return resolve(JSON.parse(data.value_data));
        return resolve(data.COUNT);
      }
    });
  }

  getunsyncedSubmittedNDapplications() {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        "SELECT * FROM nd_withdrawal_application WHERE sync_flag = 'N' and application_status='SBMTD';"
      );
      await this.db.close();

      if (qryResponse.values.length === 0) {
        return resolve(null);
      } else {
        //console.log(qryResponse.values);
        let data = qryResponse.values;
        // return resolve(JSON.parse(data.value_data));
        // return resolve(data.value_data);
        return resolve(data);
      }
    });
  }

  getNDapplicationDataByGeoLocation(
    geolocation,
    fnpfno,
    Duplicatelocationarea
  ) {
    return new Promise(async (resolve) => {
      let latitude = 0;
      let longitude = 0;

      if (geolocation && geolocation !== '' && geolocation !== '{}') {
        let location = JSON.parse(geolocation);
        if (location && location.latitude && location.longitude) {
          longitude = location.longitude;
          latitude = location.latitude;
        }
      }

      if (Duplicatelocationarea === 0) {
        Duplicatelocationarea = 0.001;
      }

      if (latitude && longitude) {
        let latitude_from = latitude - Duplicatelocationarea;
        let latitude_to = latitude + Duplicatelocationarea;

        let longitude_from = longitude - Duplicatelocationarea;
        let longitude_to = longitude + Duplicatelocationarea;
        await this.hasDB();
        await this.db.open();
        let qryResponse = await this.db.query(
          'SELECT * FROM nd_withdrawal_application WHERE latitude >= ' +
          latitude_from +
          ' and latitude <= ' +
          latitude_to +
          ' and longitude >= ' +
          longitude_from +
          ' and longitude <= ' +
          longitude_to +
          " and fnpf_no != '" +
          fnpfno +
          "' ;"
        );
        await this.db.close();
        if (qryResponse.values.length === 0) {
          return resolve(null);
        } else {
          let data = qryResponse.values;
          return resolve(data);
        }
      } else {
        return resolve(null);
      }
    });
  }

  setSubmittedNDapplicationData(
    fnpf_no,
    geo_location,
    member_first_name,
    member_full_name,
    application_status
  ): Promise<boolean> {
    let latitude = 0;
    let longitude = 0;
    if (geo_location && geo_location !== '' && geo_location !== '{}') {
      let location = JSON.parse(geo_location);
      if (location && location.latitude && location.longitude) {
        longitude = location.longitude;
        latitude = location.latitude;
      }
    }

    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        "SELECT * FROM submitted_nd_withdrawal_application WHERE fnpf_no = '" +
        fnpf_no +
        "';"
      );
      //console.log(qryResponse);
      if (qryResponse.values.length === 0) {
        const id = this.uuidv4();
        let insertQry =
          "INSERT INTO submitted_nd_withdrawal_application (id, fnpf_no, geo_location, member_first_name, member_full_name,application_status,latitude,longitude) VALUES ('" +
          id +
          "', '" +
          fnpf_no +
          "', '" +
          geo_location +
          "', '" +
          member_first_name +
          "', '" +
          member_full_name +
          "', '" +
          application_status +
          "', " +
          latitude +
          ', ' +
          longitude +
          ');';
        //console.log(insertQry);

        let insertResponse = await this.db.run(insertQry);
        if (insertResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(insertResponse);
        }
      } else {
        let updateQry =
          "UPDATE submitted_nd_withdrawal_application SET geo_location = '" +
          geo_location +
          "',member_first_name = '" +
          member_first_name +
          "',member_full_name = '" +
          member_full_name +
          "',application_status = '" +
          application_status +
          "',latitude = " +
          latitude +
          ',longitude = ' +
          longitude +
          " WHERE fnpf_no = '" +
          fnpf_no +
          "'";
        let updateResponse = await this.db.execute(updateQry);
        if (updateResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(updateResponse);
        }
      }
    });
  }

  getSubmittedNDapplicationData(key) {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        "SELECT * FROM submitted_nd_withdrawal_application WHERE fnpf_no = '" +
        key +
        "';"
      );
      await this.db.close();
      if (qryResponse.values.length === 0) {
        return resolve(null);
      } else {
        //console.log(qryResponse);
        let data = qryResponse.values[0];
        return resolve(data);
      }
    });
  }

  getSubmittedNDapplicationDataByGeoLocation(
    geolocation,
    fnpfno,
    Duplicatelocationarea
  ) {
    return new Promise(async (resolve) => {
      let latitude = 0;
      let longitude = 0;

      if (geolocation && geolocation !== '' && geolocation !== '{}') {
        let location = JSON.parse(geolocation);
        if (location && location.latitude && location.longitude) {
          longitude = location.longitude;
          latitude = location.latitude;
        }
      }

      if (Duplicatelocationarea === 0) {
        Duplicatelocationarea = 0.001;
      }

      if (latitude && longitude) {
        let latitude_from = latitude - Duplicatelocationarea;
        let latitude_to = latitude + Duplicatelocationarea;

        let longitude_from = longitude - Duplicatelocationarea;
        let longitude_to = longitude + Duplicatelocationarea;
        await this.hasDB();
        await this.db.open();
        let qryResponse = await this.db.query(
          'SELECT * FROM submitted_nd_withdrawal_application WHERE latitude >= ' +
          latitude_from +
          ' and latitude <= ' +
          latitude_to +
          ' and longitude >= ' +
          longitude_from +
          ' and longitude <= ' +
          longitude_to +
          " and fnpf_no != '" +
          fnpfno +
          "' ;"
        );
        await this.db.close();
        if (qryResponse.values.length === 0) {
          return resolve(null);
        } else {
          let data = qryResponse.values;
          return resolve(data);
        }
      } else {
        return resolve(null);
      }
    });
  }

  eraseDeviseData() {
    return new Promise(async (resolve) => {
      await this.hasDB();
      await this.db.open();
      let qryResponse = await this.db.query(
        'DELETE FROM app_data; DELETE FROM offline_login; DELETE FROM member_info; DELETE FROM nd_withdrawal_application;'
      );
      await this.db.close();
      return resolve(null);
    });
  }


  async deleteDatabase(): Promise<void> {
    try {
      if (this.db) {
        let ret: any = await this.db.isExists();
        if (ret.result) {
          // const dbName = this.db.getConnectionDBName();
          await this.db.delete();
          return Promise.resolve();
        } else {
          return Promise.resolve();
        }
      } else {
        //console.log('DB not initialized');
        return Promise.reject('DB not initialized');
      }
    } catch (err) {
      return Promise.reject(err);
    }
  }


}
