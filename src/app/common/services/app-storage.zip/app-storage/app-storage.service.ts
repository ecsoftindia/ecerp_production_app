import { Injectable } from '@angular/core';
import {
  CapacitorSQLite,
  capSQLiteChanges,
  capSQLiteResult,
  SQLiteConnection,
  SQLiteDBConnection,
} from '@capacitor-community/sqlite';
import { Capacitor } from '@capacitor/core';
import { Device } from '@capacitor/device';
import { Directory, Encoding, Filesystem } from '@capacitor/filesystem';
import { AlertController } from '@ionic/angular';
import { format } from 'date-fns';
import { FullSpinnerService } from '../../full-spinner/full-spinner.service';
import { dbschema, sampleDb, sqlDB, sampleDbform, sqlDB1 } from './app-storage-db-schema';

@Injectable({
  providedIn: 'root',
})
export class AppStorageService {
  platform: string = '';
  sqlitePlugin: any;
  sqlite: SQLiteConnection;
  isService: boolean = false;
  native: boolean = false;
  private initPlugin: boolean = false;
  public isWeb: boolean = false;
  db: SQLiteDBConnection;
  db1: SQLiteDBConnection;
  dbName = '';
  dbName1 = '';
  logDeviceInfo: any = {};
  deviceId: any = {};

  constructor(
    public alertCtrl: AlertController,
    public fullspinner: FullSpinnerService,
  ) {

    this.dbName = sqlDB.database;
    this.dbName1 = sqlDB1.database;


  }

  initializeSQlite(): Promise<boolean> {
    return new Promise((resolve) => {
      this.platform = Capacitor.getPlatform();
      // //console.log(this.platform);
      if (this.platform === 'ios' || this.platform === 'android') {
        this.native = true;
      }
      this.sqlitePlugin = CapacitorSQLite;
      this.sqlite = new SQLiteConnection(this.sqlitePlugin);
      this.isService = true;
      resolve(true);
    });
  }

  init() {
    debugger
    this.initializeSQlite().then(async (res) => {
      this.initPlugin = res;
      const p: string = this.platform;
      if (p === 'web') {
        this.isWeb = true;
        await customElements.whenDefined('jeep-sqlite');
        const jeepSqliteEl: any = document.querySelector('jeep-sqlite');
        console.log(jeepSqliteEl);
        if (jeepSqliteEl != null) {
          await this.initWebStore();
        } else {
          this.showAlert('jeepSqliteEl is null');
          //console.log('$$ jeepSqliteEl is null');
        }
      }
      try {
        const isSet = await this.isPassPhrase();
        if (!isSet.result) {
          await this.setEncryptionSecret();
        }

        let dbAvailable = await this.isDatabase();
        // //console.log(dbAvailable);
        if (!dbAvailable.result) {
          this.createDb();
          this.createTable();
        } else {
          this.connectDb();
        }
        console.log("db hitted")

      } catch (error) {
        this.showAlert(`Error: ${error}`);
        //console.log(`Error: ${error}`); 
        this.initPlugin = false;
      }
    });
  }

  getDeviceinfo() {
    debugger
    this.deviceId = Device.getId();
    console.log(this.deviceId)
  }

  createTable() {
    let dbTable = sampleDb;
    const obj = {
      database: 'hse_db250',
      version: 1,
      encrypted: true,
      mode: 'partial',
      tables: []
    }
    dbTable.forEach(element => {
      obj.tables.push(JSON.parse(JSON.stringify(element)));
    });
    let dbTable1 = sampleDbform;
    const obj1 = {
      database: 'hse_db251',
      version: 1,
      encrypted: true,
      mode: 'partial',
      tables: []
    }
    dbTable1.forEach(element => {
      obj1.tables.push(JSON.parse(JSON.stringify(element)));
    });
    console.log("table created", obj);
    console.log("table1 created", obj1);

    this.upDateTable(obj, obj1);
  }

  // passphrase available
  async isPassPhrase(): Promise<capSQLiteResult> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(await this.sqlite.isSecretStored());
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }
  // set encryption passphrase
  async setEncryptionSecret(): Promise<void> {
    if (this.sqlite != null) {
      try {
        await this.sqlite.setEncryptionSecret(sqlDB.secretPhrase);
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }

  // web
  async initWebStore(): Promise<void> {
    if (this.platform !== 'web') {
      return Promise.reject(
        new Error(`not implemented for this platform: ${this.platform}`)
      );
    }
    if (this.sqlite != null) {
      try {
        let webStore = await this.sqlite.initWebStore();
        this.logger('webstore' + webStore);
        return Promise.resolve();
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }

  // alert
  async showAlert(msg) {
    const alert = await this.alertCtrl.create({
      header: 'Error',
      message: msg,
      buttons: ['OK'],
    });
    await alert.present();
  }

  // dbAvaliable
  async isDatabase(): Promise<capSQLiteResult> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(await this.sqlite.isDatabase(this.dbName));
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }

  // create Db
  async createDb() {
    debugger
    this.db = await this.createDbConnection();
    this.db1 = await this.createDbConnection1();
    console.log('returned');
    await this.db.open();
    await this.db1.open();
    let ret: any = await this.db.execute(dbschema);
    let ret1: any = await this.db1.execute(dbschema);
    console.log('schema created');
    // console.log(await this.db.exportToJson('full'));

    if (ret.changes.changes < 0) {
      return Promise.reject(new Error('Execute createSchema failed'));
    }
    if (ret1.changes.changes < 0) {
      return Promise.reject(new Error('Execute createSchema failed'));
    }

    await this.db.close();
    await this.db1.close();
  }

  async exportDb(){
    debugger
    await this.db.open();
    // let ret: any = await this.db.execute(dbschema);
    this.db.createSyncTable();
    let jsonValue = await this.db.exportToJson('full');
    // console.log(`jsonValue ${JSON.stringify(jsonValue.export)}`,"exported db");
    // this.getDeviceinfo();
    let exportData = (JSON.stringify(jsonValue.export));
    // const fileName = new Date().getTime() + '.jpeg';
    const savedFile = await Filesystem.writeFile({
      path: 'DB',
      data: exportData,
      directory: Directory.Documents,
      encoding: Encoding.UTF8,
    });
    console.log(savedFile,"afterExport");
    // return {
    //   filepath: fileName,
    //   webviewPath: exportData.webPath
    // };
  }
  async connectDb() {
    this.db = await this.createDbConnection();
    this.db1 = await this.createDbConnection1();
  }

  async disconnectDb() {
    await this.sqlite.closeAllConnections();
  }

  private async createDbConnection(): Promise<SQLiteDBConnection> {
    if ((await this.isConnection()).result) {
      const db = await this.retrieveConnection();
      if (db != null) {
        return Promise.resolve(db);
      } else {
        return Promise.reject(new Error(`no db returned is null`));
      }
    } else {
      if (this.sqlite != null) {
        try {
          const db: SQLiteDBConnection = await this.sqlite.createConnection(
            this.dbName,
            sqlDB.encrypted,
            sqlDB.mode,
            sqlDB.version
          );
          if (db != null) {
            console.log('db-created', db);
            return Promise.resolve(db);
          } else {
            return Promise.reject(new Error(`no db returned is null`));
          }
        } catch (err) {
          //console.log(err);
          return Promise.reject(new Error(err));
        }
      }
    }
  }

  private async createDbConnection1(): Promise<SQLiteDBConnection> {
    if ((await this.isConnection1()).result) {
      const db1 = await this.retrieveConnection1();
      if (db1 != null) {
        return Promise.resolve(db1);
      } else {
        return Promise.reject(new Error(`no db returned is null`));
      }
    } else {
      if (this.sqlite != null) {
        try {
          const db1: SQLiteDBConnection = await this.sqlite.createConnection(
            this.dbName1,
            sqlDB.encrypted,
            sqlDB.mode,
            sqlDB.version
          );
          if (db1 != null) {
            console.log('db-created', db1);
            return Promise.resolve(db1);
          } else {
            return Promise.reject(new Error(`no db returned is null`));
          }
        } catch (err) {
          //console.log(err);
          return Promise.reject(new Error(err));
        }
      }
    }
  }
  async retrieveConnection(): Promise<SQLiteDBConnection> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(
          await this.sqlite.retrieveConnection(this.dbName)
        );
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open for ${this.dbName}`));
    }
  }

  async retrieveConnection1(): Promise<SQLiteDBConnection> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(
          await this.sqlite.retrieveConnection(this.dbName1)
        );
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open for ${this.dbName1}`));
    }
  }
  async isConnection(): Promise<capSQLiteResult> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(await this.sqlite.isConnection(this.dbName));
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }
  async isConnection1(): Promise<capSQLiteResult> {
    if (this.sqlite != null) {
      try {
        return Promise.resolve(await this.sqlite.isConnection(this.dbName1));
      } catch (err) {
        return Promise.reject(new Error(err));
      }
    } else {
      return Promise.reject(new Error(`no connection open`));
    }
  }
  async deleteDatabase(): Promise<void> {
    try {
      if (this.db) {
        let ret: any = await this.db.isExists();
        //console.log(ret);
        debugger;
        if (ret.result) {
          const dbName = this.db.getConnectionDBName();
          await this.db.delete();
          await this.sqlite.closeAllConnections();
          return Promise.resolve();
        } else {
          return Promise.resolve();
        }
      } else {
        //console.log('DB not initialized');
        return Promise.reject('DB not initialized');
      }
    } catch (err) {
      return Promise.reject(err);
    }
  }

  uuidv4() {
    return Math.random().toString().slice(2, 8);
  }

  proccessQuery(qry, type): Promise<any> {
    debugger
    // select - query, insert - run , update - execute
    return new Promise((resolve) => {
      const interval = setInterval(async () => {
        if (this.db) {
          this.fullspinner.empty.next(true);
          clearInterval(interval);
          await this.db.open();
          let qryResponse: any = '';
          switch (type) {
            case 'query':
              qryResponse = await this.db.query(qry);
              break;
            case 'run':
              qryResponse = await this.db.run(qry);
              break;
            case 'execute':
              qryResponse = await this.db.execute(qry);
              break;
            default:
              break;
          }
          await this.db.close();
          this.fullspinner.empty.next(false);
          resolve(qryResponse);
        } else {
          //console.log('DB is Null');
        }
      }, 10);
    });
  }

  proccessQuery2(qry, type): Promise<any> {
    debugger
    // select - query, insert - run , update - execute
    return new Promise((resolve) => {
      const interval = setInterval(async () => {
        if (this.db1) {
          this.fullspinner.empty.next(true);
          clearInterval(interval);
          await this.db1.open();
          let qryResponse: any = '';
          switch (type) {
            case 'query':
              qryResponse = await this.db1.query(qry);
              break;
            case 'run':
              qryResponse = await this.db1.run(qry);
              break;
            case 'execute':
              qryResponse = await this.db1.execute(qry);
              break;
            default:
              break;
          }
          await this.db1.close();
          this.fullspinner.empty.next(false);
          resolve(qryResponse);
        } else {
          //console.log('DB is Null');
        }
      }, 10);
    });
  }


  setData(key, value): Promise<boolean> {
    return new Promise(async (resolve) => {
      let selectQry = "SELECT * FROM app_data WHERE key_name = '" + key + "';";
      let qryResponse = await this.proccessQuery(selectQry, 'query');
      let jvalue = JSON.stringify(value);
      jvalue = jvalue.replace(/\'/g, "''");
      const date_added = format(new Date(), 'yyyy-MM-dd HH:mm');
      if (qryResponse.values.length === 0) {
        const id = this.uuidv4();
        let insertQry =
          "INSERT INTO app_data (id, key_name, value_data, date_added) VALUES ('" +
          id +
          "', '" +
          key +
          "', '" +
          jvalue +
          "', '" +
          date_added +
          "');";
        let insertResponse = await this.proccessQuery(insertQry, 'run');
        if (insertResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(insertResponse);
        }
      } else {
        // //console.log('Update Qry');
        let updateQry =
          "UPDATE app_data SET value_data = '" +
          jvalue +
          "' WHERE key_name = '" +
          key +
          "'";
        let updateResponse = await this.proccessQuery(updateQry, 'execute');
        if (updateResponse.changes) {
          resolve(true);
        } else {
          this.showAlert(updateResponse);
        }
      }
    });
  }

  getData(key) {
    return new Promise(async (resolve) => {
      let selectQry = "SELECT * FROM app_data WHERE key_name = '" + key + "';";
      let qryResponse = await this.proccessQuery(selectQry, 'query');
      if (qryResponse.values.length === 0) {
        return resolve(null);
      } else {
        let data = qryResponse.values[0];
        return resolve(JSON.parse(data.value_data));
      }
    });
  }

  logger(val: any) {
    //console.log(val);
  }

  // eraseDeviseData() {
  //   return new Promise(async (resolve) => {
  //     let deleteQry =
  //       'DELETE FROM app_data; DELETE FROM offline_login; DELETE FROM member_info; DELETE FROM nd_withdrawal_application;';
  //     let qryResponse = await this.proccessQuery(deleteQry, 'query');
  //     return resolve(null);
  //   });
  // }

  async upDateTable(obj, obj1) {
    debugger
    console.log(obj, obj1, "Errorplace")
    let result = await this.sqlite.isJsonValid(JSON.stringify(obj));
    if (!result.result) {
      return Promise.reject(new Error('IsJsonValid failed'));
    } else {
      console.log("json success 1",)
    }
    let result1 = await this.sqlite.isJsonValid(JSON.stringify(obj1));
    if (!result1.result) {
      return Promise.reject(new Error('IsJsonValid failed'));
    } else {
      console.log("json success 2",)
    }

    // full import
    let resultUpdate = await this.sqlite.importFromJson(JSON.stringify(obj));

    console.log(resultUpdate, "importstringfy")
    if (resultUpdate.changes.changes === -1) {
      return Promise.reject(
        new Error("ImportFromJson 'full' dataToImport failed")
      );
    }
    else {
      console.log("Data Updated in sqllite");
      console.log("Before select data");
      // this.selectData();
      console.log("After select data");
    }



    let resultSync: any = await this.db.createSyncTable();
    if (resultSync.changes.changes < 0) return Promise.reject(new Error("CreateSyncTable failed"));


    let resultSyncDate: any = await this.db.getSyncDate();
    if (resultSyncDate.length === 0) return Promise.reject(new Error("GetSyncDate failed"));


    let resultUpdate1 = await this.sqlite.importFromJson(JSON.stringify(obj1));
    console.log(resultUpdate1, "importstringfy")
    if (resultUpdate1.changes.changes === -1) {
      return Promise.reject(
        new Error("ImportFromJson 'full' dataToImport failed")
      );
    }
    else {
      console.log("Data Updated in sqllite");
      console.log("Before select data1");
      // this.selectData();
      console.log("After select data1");
    }
  }
  async selectData() {
    let selectQry =
      "SELECT * FROM APP_PROJECT_DIVISION;";
    let qryResponse = await this.proccessQuery(selectQry, 'query');
    console.log(qryResponse);
  }
  async insertData() {
    let selectQry =
      "INSERT INTO APP_PROJECT VALUES (1,'Soap','PR22021601','Soap 1',2,'VIKIN','Vikings',1,'DOVE','Dovyy','2022-02-04 00:00:00','2022-12-30 00:00:00',115,'ACTIV','Admin','2022-02-16 18:32:04','Vijay','2022-02-18 16:31:28','N',1);";
    let qryResponse = await this.proccessQuery(selectQry, 'query');
    console.log(qryResponse, 'update');
  }
  async updateData() {
    let selectQry =
      "UPDATE  APP_PROJECT SET PROJECT_REF_NO='shaji' WHERE CLIENT_COMPANY_ID=2";
    let qryResponse = await this.proccessQuery(selectQry, 'query');
    console.log(qryResponse, 'update');
  }


  // Query

  async getUser() {
    return new Promise(async (resolve) => {
      let selectQry =
        "select * from APP_TABLET_STAFF ats  inner join APP_CREW ac on ac.CREW_SUPERVISOR_STAFF_ID=ats.TABLET_STAFF_ID";
      let qryResponse = await this.proccessQuery(selectQry, 'query');
      if (qryResponse.values.length === 0) {
        return resolve(null);
      } else {
        let data = qryResponse.values;
        return resolve(data);
      }
    });
  }

}
